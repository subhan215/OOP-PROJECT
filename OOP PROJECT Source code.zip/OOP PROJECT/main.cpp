#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>
#include <string>
#include <fstream>
#include <string.h>
#include <conio.h>
#include <sstream>
#include <cstdlib>
#include <ctime>
class dateOfBirth
{
    
public:
    int day, month, year;
};
class creditCard
{
public:
    int expiry_month;
    int expiry_year;
};
struct userData
{
public:
    std::string fName, lName, password, email, phoneNo, role;
    dateOfBirth dOB;
    int uId;
    long int amountWithdrawOrDonate;
    long int amountInAccount;
};
struct verification
{
public:
    std::string cnicORcompanyNo, bankAccountNo;
    bool verify;
    std::string accountType;
};
struct StudentPost
{
    std::string instituteName;
    double amount;
    struct matric
    {
        std::string grade;
        float percentage;
        float obtMarks;
    } m, hsc;
    int correctAnswers;
};
struct hackathon
{
    std::string name, theme, venue;
    dateOfBirth date;
    long long int prize;
    int noOfParticipants;
    std::string judges[3];
    std::string rules[5];
};
struct loaneePost
{
    double amount;
    std::string purpose, jobTitle, employeementType;
    double monthlyIncome;
    struct taxDetails
    {
        float annualTax;
        bool paidStatus;
    } t;
};
struct patientPost
{
    double amount;
    std::string hospitalName, disease, processName;
    float income, expenses;
};
class User
{
protected:
    userData uD;
    verification v;

public:
    void validateDate(dateOfBirth &date)
    {
        if (date.year < 1900 || date.year > 2010)
        {
            std::cout << "\nInvalid year!Enter again ";
            std::cin >> date.year;
            validateDate(date);
        }
        if (date.year < 0)
        {
            std::cout << "\nInvalid year!Enter again ";
            std::cin >> date.year;
            validateDate(date);
        }
        if (date.month < 1 || date.month > 12)
        {
            std::cout << "\nInvalid month!Enter again ";
            std::cin >> date.month;
            validateDate(date);
        }
        if (date.day < 1 || date.day > 31)
        {
            std::cout << "\nInvalid day!Enter again ";
            std::cin >> date.day;
            validateDate(date);
        }
        if ((date.month == 4 || date.month == 6 || date.month == 9 || date.month == 11) && date.day > 30)
        {
            std::cout << "\nInvalid month!Enter again ";
            std::cin >> date.month;
            validateDate(date);
        }
        if (date.month == 2)
        {
            if (date.year % 4 == 0 && (date.year % 100 != 0 || date.year % 400 == 0))
            { // leap year
                if (date.day > 29)
                {
                    std::cout << "\nInvalid day!Enter again ";
                    std::cin >> date.day;
                    validateDate(date);
                }
            }
            else
            { // not a leap year
                if (date.day > 28)
                {
                    std::cout << "\nInvalid day!Enter again ";
                    std::cin >> date.day;
                    validateDate(date);
                }
            }
        }
    }
    void creditCardDateValid(creditCard &cc)
    {
        // Get current time
        std::time_t now = std::time(nullptr);
        std::tm *tm_now = std::gmtime(&now);
        int current_year = tm_now->tm_year + 1900;
        int current_month = tm_now->tm_mon + 1;

        // Check expiry year
        if (cc.expiry_year < current_year || cc.expiry_year > current_year + 10)
        {
            std::cout << "\nInvalid Year! Enter again: ";
            std::cin >> cc.expiry_year;
            creditCardDateValid(cc);
        }

        // Check expiry month
        if (cc.expiry_month < 1 || cc.expiry_month > 12)
        {
            std::cout << "\nInvalid Month! Enter again: ";
            std::cin >> cc.expiry_month;
            creditCardDateValid(cc);
        }
        if (cc.expiry_year == current_year && cc.expiry_month < current_month)
        {
            std::cout << "\nInvalid Month! Enter again: ";
            std::cin >> cc.expiry_month;
            creditCardDateValid(cc);
        }
    }
    int *creditCardValid()
    {
        int a = 16, i, j, k, total, firstNumber;
        int sum1 = 0;
        int sum2 = 0;
        // Registers the number of digits in the credit card.
        int cardNumber[16];
        int *creditCardNo = new int[sizeof(int) * a];
        // Takes the credit card number in the order from left to right.
        std::cout << "\nEnter Your Credit Card Number : ";
        for (j = 1; j <= a; j++)
        {
            int num;
            std::cout << j << ": ";
            std::cin >> num;
            cardNumber[j] = num, creditCardNo[j - 1] = num;
        }
        firstNumber = cardNumber[1];
        // Application of Luhn Algorithm.
        for (i = (a - 1); i > 0; i = i - 2)
        {
            cardNumber[i] = cardNumber[i] * 2;
            if (cardNumber[i] > 9)
            {
                cardNumber[i] = cardNumber[i] - 9;
                sum1 = sum1 + cardNumber[i];
            }
            else
            {
                sum1 = sum1 + cardNumber[i];
            }
        }
        for (k = a; k > 0; k = k - 2)
        {
            sum2 = sum2 + cardNumber[k];
        }
        total = sum1 + sum2;
        if (total % 10 == 0)
        {
            return creditCardNo;
        }
        else
        {
            printf("\n-->Your Credit Card Number Is Not Valid ! \n");
            creditCardValid();
        }
    }
    void phoneNoValidation(std::string *number)
    {
        char i, length;
        while (1)
        {
            fflush(stdin);
            length = (*number).length();

            if ((*number)[0] == '0')
            {
                if (length == 11)
                {
                    std::cout << "\nYour Phone Number Is Verified ! ";
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! \nEnter A Valid Phone Number : ";
                    std::cin >> *number;
                }
            }
            else if ((*number)[0] == '+')
            {
                if ((*number)[1] == '9')
                {
                    if ((*number)[2] == '2')
                    {
                        if (length == 13)
                        {
                            std::cout << "\nPhone Number is verified !";
                            break;
                        }
                    }
                }
            }
            else
            {
                std::cout << "\nInvalid! \nEnter a valid phone number : \n";
                std::cin >> *number;
            }
        }
    }
    void check_string(std::string *s)
    {
        bool check = false;
        while (1)
        {
            for (int i = 0; i < (*s).length(); i++)
            {
                if (!isalpha((*s)[i]))
                {
                    check = true;
                }
            }
            if (check == true)
            {
                std::cout << "\nExcept alphabets other characters are not allowed!!";
                std::cout << "\nEnter again: ";
                fflush(stdin);
                std::cin >> (*s);
                check = false;
                continue;
            }
            else
            {
                break;
            }
        }
    }
    void checkNumber(std::string *s)
    {
        bool check = true;
        while (1)
        {
            for (char c : *s)
            {
                if (!isdigit(c))
                {
                    check = false;
                    break;
                }
            }
            if (check == false)
            {
                std::cout << "\nInvaid Input!\nEnter again: ";
                fflush(stdin);
                std::cin >> (*s);
                check = true;
                continue;
            }
            else
            {
                break;
            }
        }
    }
    void checkAnswerChoice(std::string *s)
    {
        bool check = false;
        while (1)
        {
            for (int i = 0; i < (*s).length(); i++)
            {
                if (!isalpha((*s)[i]) || ((*s)[i] != 'A' && (*s)[i] != 'B' && (*s)[i] != 'C' && (*s)[i] != 'D'))
                {
                    check = true;
                }
            }
            if (check == true)
            {
                std::cout << "\nExcept A , B , C , D other characters are not allowed!!";
                std::cout << "\nEnter again: ";
                fflush(stdin);
                std::cin >> (*s);
                check = false;
                continue;
            }
            else if (s->length() > 1)
            {
                std::cout << "\nOnly 1 character is allowed! ";
                std::cout << "\nEnter again: ";
                fflush(stdin);
                std::cin >> (*s);
                check = false;
                continue;
            }
            else
            {
                break;
            }
        }
    }
    std::string vemail(std::string email)
    {
        bool ver = false;
        int counter, alpha = 0, dot = 0;
        do
        {
            for (counter = 0; email[counter] != '\0'; counter++)
            {
                if (email[counter] == '@')
                    alpha = counter;
                if (email[counter] == '.')
                    dot = counter;
                if (email[alpha + 1] == '\0')
                {
                    std::cout << "\nInvalid E-mail\n";
                    return "";
                }
                else
                {
                    ver = true;
                }
            }
            if (alpha > 2 && (dot - alpha) > 3 && ver)
            {
                std::cout << "\ne-mail Verified..\n";
                return email;
            }

            else
            {
                std::cout << "\nInvalid E-mail\n";
                return "";
            }
        } while (alpha < 2 && (dot - alpha) < 3 && ver);
    }
    std::string passwordFormatCheck(std::string password)
    {
        bool hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;
        int length = password.length();
        for (int i = 0; i < length; i++)
        {
            if (isupper(password[i]))
                hasUpper = true;
            if (islower(password[i]))
                hasLower = true;
            if (isdigit(password[i]))
                hasDigit = true;
            if (ispunct(password[i]))
                hasSpecial = true;
        }
        if (!hasUpper)
        {
            std::cout << "\nincorrect pattern of password..\n";
            return "";
        }
        if (!hasLower)
        {
            std::cout << "\nincorrect pattern of password..\n";
            return "";
        }
        if (!hasDigit)
        {
            std::cout << "\nincorrect pattern of password..\n";
            return "";
        }
        if (!hasSpecial)
        {
            std::cout << "\nincorrect pattern of password..\n";
            return "";
        }
        else
        {
            std::cout << "\nPassword verified!!\n\n";
            return password;
        }
    }
    void logOut(int uId, int *logOutChoice)
    {
        std::cout << "\nDo you want to logout: \n1: yes \n2: no\nEnter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> *logOutChoice;
            if (*logOutChoice == 1 || *logOutChoice == 2)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid! \nEnter again: ";
                continue;
            }
        }
        if (*logOutChoice == 1)
        {
            std::string filePath = "currentlyLogin.txt";
            std::remove(filePath.c_str());
        }
    }
    void signUp()
    {
        std::cout << "\033[2J\033[1;1H";
        std::cout << "     ********** SIGN UP ***********";
        std::cout << "\nEnter first name: ";
        fflush(stdin);
        std::cin >> uD.fName;
        check_string(&uD.fName);
        std::cout << "\nEnter last name: ";
        fflush(stdin);
        std::cin >> uD.lName;
        check_string(&uD.lName);
        while (1)
        {
            int found = 0;
            while (1)
            {
                std::string tempEmail;
                std::cout << "\nEnter email: ";
                fflush(stdin);
                std::cin >> tempEmail;
                uD.email = vemail(tempEmail);
                if (uD.email != "")
                {
                    break;
                }
                else
                {
                    continue;
                }
            }

            std::ifstream infile("users.txt");
            std::string line;
            while (std::getline(infile, line))
            {
                if (line.substr(0, uD.email.length()) == uD.email)
                {
                    found = 1;
                    std::cout << "This email already exists. Please try again with a different email." << std::endl;
                    break;
                }
            }

            if (found == 0)
            {
                break;
            }
        }
        std::cout << "\nEnter phone no: ";
        fflush(stdin);
        std::cin >> uD.phoneNo;
        checkNumber(&uD.phoneNo);
        phoneNoValidation(&uD.phoneNo);
        std::string dateInput;
        std::cout << "\nEnter date of birth: \n";
        std::cout << "day: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        uD.dOB.day = stoi(dateInput);
        std::cout << "\nmonth: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        uD.dOB.month = stoi(dateInput);
        std::cout << "\nyear: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        uD.dOB.year = stoi(dateInput);
        validateDate(uD.dOB);
        std::cout << "\nEnter your role(N/n for needy, D/n for donor --> other keywords are not accepted! )";
        while (1)
        {
            fflush(stdin);
            std::cin >> uD.role;
            if (uD.role == "n" || uD.role == "N" || uD.role == "d" || uD.role == "D")
            {
                break;
            }
            else
            {
                std::cout << "\nWrong role! \nEnter your role again: ";
                continue;
            }
        }
        while (1)
        {
            std::string tempPass;
            std::cout << "\nEnter password: ";
            fflush(stdin);
            std::cin >> tempPass;
            uD.password = passwordFormatCheck(tempPass);
            if (uD.password != "")
            {
                break;
            }
            else
            {
                continue;
            }
        }

        std::cout << "\nConfirm password: ";
        std::string confirmPassword;
        while (1)
        {
            fflush(stdin);
            std::cin >> confirmPassword;
            if (uD.password == confirmPassword)
            {
                srand(time(NULL));
                uD.uId = 10 * rand();
                std::string filePath = std::to_string(uD.uId) + ".txt";
                std::ofstream Write(filePath, std::ios::binary);
                if (Write.is_open())
                {
                    Write << uD.uId << "\n"
                          << uD.fName << "\n"
                          << uD.lName << "\n"
                          << uD.email << "\n"
                          << uD.password << "\n"
                          << uD.phoneNo << "\n"
                          << uD.role << "\n"
                          << uD.dOB.day << "\n"
                          << uD.dOB.month << "\n"
                          << uD.dOB.year << "\n"
                          << false << "\n";
                    Write.close();
                }
                FILE *filePtr = fopen("noOfUsers.txt", "r");
                int noOfUsers;
                fscanf(filePtr, "%d", &noOfUsers, sizeof(int));
                fclose(filePtr);
                filePtr = fopen("noOfUsers.txt", "w");
                fprintf(filePtr, "%d", noOfUsers + 1);
                fclose(filePtr);
                std::ofstream outfile("users.txt", std::ios::app);
                outfile << uD.email << " " << filePath << std::endl;
                outfile.close();
                std::cout << "Registration successful!" << std::endl;
                break;
            }
            else
            {
                std::cout << "\nPlease enter correct password!Enter again: ";
            }
        }
    };
    std::string getPassword()
    {
        return uD.password;
    }
    void verifyBankAccount(std::string *accountNo)
    {
        bool verified = false;
        while (1)
        {
            std::ifstream infile("approved bank accounts.txt");
            std::string line;
            while (getline(infile, line))
            {
                if (line == *accountNo)
                {
                    std::cout << "\nVerified Bank Account!";
                    verified = true;
                    break;
                }
            }
            infile.close();
            if (verified == true)
            {
                break;
            }
            else
            {
                std::cout << "\nUnverified bank account!";
                std::cout << "\nEnter bank account number again: ";
                fflush(stdin);
                std::cin >> *accountNo;
                continue;
            }
        }
    }
    void editProfile(userData &u, verification &v)
    {
        std::cout << "\nWhat do you want to edit \n1: first name \n2: last name \n3: email \n4: password \n5: phone number"
                  << "\n6: date of birth \n7: bank account number\n8: Exit";
        int choice;
        std::cout << "\nEnter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> choice;
            if (choice >= 1 && choice <= 8)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid Choice! Enter again: ";
                continue;
            }
        }
        if (choice == 1)
        {
            std::cout << "\nEnter new first name: ";
            fflush(stdin);
            std::cin >> u.fName;
            check_string(&u.fName);
        }
        else if (choice == 2)
        {
            std::cout << "\nEnter new last name: ";
            fflush(stdin);
            std::cin >> u.lName;
            check_string(&u.lName);
        }
        else if (choice == 3)
        {
            std::ifstream Read("users.txt");
            std::ofstream Write("temp.txt");
            std::string line;
            while (std::getline(Read, line))
            {
                std::string fileEmail = line.substr(0, u.email.length());
                if (fileEmail == u.email)
                {
                    std::cout << "\nEnter new email: ";
                    fflush(stdin);
                    std::cin >> u.email;
                    line = u.email + " " + std::to_string(u.uId) + ".txt";
                }
                Write << line << "\n";
            }
            Read.close();
            Write.close();
            std::remove("users.txt");
            std::rename("temp.txt", "users.txt");
        }
        else if (choice == 4)
        {
            std::cout << "\nEnter old password: ";
            std::string oldPassword, newPassword;
            fflush(stdin);
            std::cin >> oldPassword;
            if (oldPassword == u.password)
            {
                std::cout << "\nEnter new password: ";
                while (1)
                {
                    fflush(stdin);
                    std::cin >> newPassword;
                    u.password = passwordFormatCheck(newPassword);
                    if (u.password == "")
                    {
                        std::cout << "\nSorry password format not right! \nEnter again: ";
                    }
                    else
                    {
                        std::cout << "\nPassword has been reset!";
                        break;
                    }
                }
            }
        }
        else if (choice == 5)
        {
            std::cout << "\nEnter new phone number: ";
            fflush(stdin);
            std::cin >> u.phoneNo;
            checkNumber(&u.phoneNo);
            phoneNoValidation(&u.phoneNo);
        }
        else if (choice == 6)
        {
            std::string dateInput;
            std::cout << "\nEnter new date of birth: ";
            std::cout << "day: ";
            fflush(stdin);
            std::cin >> dateInput;
            checkNumber(&dateInput);
            u.dOB.day = stoi(dateInput);
            std::cout << "\nmonth: ";
            fflush(stdin);
            std::cin >> dateInput;
            checkNumber(&dateInput);
            u.dOB.month = stoi(dateInput);
            std::cout << "\nyear: ";
            fflush(stdin);
            std::cin >> dateInput;
            checkNumber(&dateInput);
            u.dOB.year = stoi(dateInput);
            validateDate(u.dOB);
        }
        else if (choice == 7)
        {
            std::cout << "\nEnter new bank account no: ";
            fflush(stdin);
            std::cin >> v.bankAccountNo;
            checkNumber(&v.bankAccountNo);
            verifyBankAccount(&v.bankAccountNo);
        }
        else if (choice == 8)
        {
            return;
        }
        else
        {
            std::cout << "\nInvalid Choice! Enter again: ";
        }
        std::string filePath = std::to_string(u.uId) + ".txt";
        std::ofstream Write(filePath);
        Write << u.uId << "\n"
              << u.fName << "\n"
              << u.lName << "\n"
              << u.email << "\n"
              << u.password << "\n"
              << u.phoneNo << "\n"
              << u.role << "\n"
              << u.dOB.day << "\n"
              << u.dOB.month << "\n"
              << u.dOB.year << "\n"
              << v.verify << "\n"
              << v.cnicORcompanyNo << "\n"
              << v.accountType << "\n"
              << v.bankAccountNo;
        if (uD.amountInAccount != -1)
        {
            Write << "\n"
                  << uD.amountInAccount;
        }
        if (uD.amountWithdrawOrDonate != -1)
        {
            Write << "\n"
                  << uD.amountWithdrawOrDonate;
        }
        Write.close();
    }
    virtual void profile()
    {
        system("cls");
        std::cout << "\nFirst Name: " << uD.fName;
        std::cout << "\nLast Name: " << uD.lName;
        std::cout << "\nEmail: " << uD.email;
        std::cout << "\nPassword: " << uD.password;
        std::cout << "\nPhone No: " << uD.phoneNo;
        std::cout << "\nRole: " << uD.role;
        std::cout << "\nDate Of Birth: " << uD.dOB.day << "/" << uD.dOB.month << "/" << uD.dOB.year;
    }
    userData &getUserData()
    {
        return uD;
    }
    void verifyCnic(std::string *cnicNo)
    {
        bool verified = false;
        while (1)
        {
            std::ifstream infile("approved cnic.txt");
            std::string line;
            while (getline(infile, line))
            {
                if (line == *cnicNo)
                {
                    std::cout << "\nVerified Cnic!";
                    verified = true;
                    break;
                }
            }
            infile.close();
            if (verified == true)
            {
                break;
            }
            else
            {
                std::cout << "\nUnverified Cnic Number!";
                std::cout << "\nEnter Cnic number again: ";
                fflush(stdin);
                std::cin >> *cnicNo;
                continue;
            }
        }
    }
    void writingData(const userData &u, const verification &v1)
    {
        std::ofstream outfile(std::to_string(u.uId) + ".txt", std::ios::binary);
        if (outfile.is_open())
        {
            outfile << u.uId << "\n"
                    << u.fName << "\n"
                    << u.lName << "\n"
                    << u.email << "\n"
                    << u.password << "\n"
                    << u.phoneNo << "\n"
                    << u.role << "\n"
                    << u.dOB.day << "\n"
                    << u.dOB.month << "\n"
                    << u.dOB.year << "\n"
                    << v1.verify << "\n"
                    << v1.cnicORcompanyNo << "\n"
                    << v1.accountType << "\n"
                    << v1.bankAccountNo << "\n"
                    << 0 << "\n";
            if (u.role == "N" || u.role == "n")
            {
                outfile << 0 << "\n";
            }
            outfile.close();
        }
    }
    void editProfAction(userData &u, verification &v)
    {
        int editProfChoice;
        std::cout << "\nDo you eant to edit your profile:\n1:Yes\n2:No\n Enter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> editProfChoice;
            if (editProfChoice == 1)
            {
                editProfile(uD, v);
                break;
            }
            else if (editProfChoice == 2)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid! Enter again: ";
                continue;
            }
        }
    }
};
class Donor : public User
{
    struct creditCardDetails
    {
        int *cardNo;
        std::string nameOnCard;
        int cvv;
        creditCard expireDate;
    } cardDetails;

public:
    Donor(){};
    Donor(const userData &u)
    {
        this->uD = u;
    }
    void verifyLicense(std::string *licenseNo)
    {
        bool verified = false;
        while (1)
        {
            std::ifstream infile("approved license.txt");
            std::string line;
            while (getline(infile, line))
            {
                if (line == *licenseNo)
                {
                    std::cout << "\nVerified License!";
                    verified = true;
                    break;
                }
            }
            infile.close();
            if (verified == true)
            {
                break;
            }
            else
            {
                std::cout << "\nUnverified License Number!";
                std::cout << "\nEnter license number again: ";
                fflush(stdin);
                std::cin >> *licenseNo;
                continue;
            }
        }
    }
    virtual void profile()
    {
        User::profile();
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        std::cout << "\nSelect any one of the following donor account types: \n1: Company \n2: Individual";
        std::cout << "\nC/c for company and I/i for individual\nEnter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> v.accountType;
            if (v.accountType == "I" || v.accountType == "i")
            {
                std::cout << "\nEnter cnic Number: ";
                fflush(stdin);
                std::cin >> v.cnicORcompanyNo;
                verifyCnic(&v.cnicORcompanyNo);
                break;
            }
            else if (v.accountType == "C" || v.accountType == "c")
            {
                std::cout << "Enter company license Number:";
                fflush(stdin);
                std::cin >> v.cnicORcompanyNo;
                verifyLicense(&v.cnicORcompanyNo);
                break;
            }
            else
            {
                std::cout << "\nInvalid! Enter again: ";
                continue;
            }
        }
        std::cout << "\nEnter bank account number: ";
        fflush(stdin);
        std::cin >> v.bankAccountNo;
        verifyBankAccount(&v.bankAccountNo);
        v.verify = true;
        writingData(uD, v);
        std::cout << "\nPress any key to continue....";
        getch();
    }
    void showingStudentPost(StudentPost &sP)
    {
        std::cout << "\nInstitute Name: " << sP.instituteName;
        std::cout << "\nAmount needed: " << sP.amount;
        std::cout << "\nMatric Details:";
        std::cout << "\nObtained Marks: " << sP.m.obtMarks;
        std::cout << "\nPercentage: " << sP.m.percentage;
        std::cout << "\nGrade: " << sP.m.grade;
        if (sP.hsc.grade != "")
        {
            std::cout << "\nIntermediate Details: ";
            std::cout << "\nObtained Marks: " << sP.hsc.obtMarks;
            std::cout << "\nPercentage: " << sP.hsc.percentage;
            std::cout << "\nGrade: " << sP.hsc.grade;
        }
    }
    void showingLoaneePost(loaneePost &lP)
    {
        std::cout << "\nAmount Needed: " << lP.amount;
        std::cout << "\nPurpose of loan: " << lP.purpose;
        std::cout << "\nEmployeement Type: " << lP.employeementType;
        std::cout << "\nJob Title: " << lP.jobTitle;
        std::cout << "\nMonthly Income" << lP.monthlyIncome;
        std::cout << "\nAnnual Tax: " << lP.t.annualTax;
        std::cout << "\nTax Paid Status: "
                  << "Paid";
    }
    void showingPatientPost(patientPost &p)
    {
        std::cout << "\nAmount Needed: " << p.amount << "\nHospital Name: "
                  << p.hospitalName << "\nDisease: " << p.disease << "\nOperatio/Process Name: "
                  << p.processName << "\nMonthly Income: " << p.income << "\nExpenses: "
                  << p.expenses;
    }
    void homeFunc(int choice, float startingRange, float endRange)
    {

        if (choice == 1)
        {
            std::ifstream Write("postsStudent.txt");
            if (Write.is_open())
            {
                int noOfPosts = 0;
                while (!Write.eof())
                {
                    std::string filePath;
                    std::getline(Write, filePath);
                    std::ifstream Post(filePath);
                    StudentPost sP;
                    sP.hsc.grade = "";

                    if (Post.is_open())
                    {
                        Post >> sP.instituteName >> sP.amount >> sP.m.obtMarks >>
                            sP.m.percentage >> sP.m.grade;
                        if (!Post.eof())
                        {
                            Post >> sP.hsc.obtMarks >> sP.hsc.percentage >> sP.hsc.grade;
                        }
                        Post.close();
                        int counter = 0;
                        while (filePath[counter] != 'p')
                        {
                            counter++;
                        }
                        filePath = filePath.substr(0, counter);
                        std::string answerFilePath = filePath + "answers.txt";
                        Post.open(answerFilePath);
                        Post >> sP.correctAnswers;
                        Post.close();
                        if (sP.amount >= startingRange && sP.amount <= endRange && sP.correctAnswers > 2)
                        {
                            std::cout << "\nPost " << noOfPosts + 1 << ":";
                            showingStudentPost(sP);
                        }
                    }
                    noOfPosts++;
                }
                Write.close();
            }
            else
            {
                std::cout << "\nSome error occured!";
            }
        }
        else if (choice == 2)
        {
            std::ifstream Write("loaneePosts.txt");
            if (Write.is_open())
            {
                int noOfPosts = 0;
                while (!Write.eof())
                {
                    std::string filePath;
                    std::getline(Write, filePath);
                    std::ifstream Post(filePath);
                    loaneePost lP;

                    if (Post.is_open())
                    {
                        Post >> lP.amount >> lP.purpose >> lP.employeementType >>
                            lP.jobTitle >> lP.monthlyIncome >> lP.t.annualTax >> lP.t.paidStatus;
                        Post.close();
                        if (lP.amount >= startingRange && lP.amount <= endRange)
                        {
                            std::cout << "\nPost " << noOfPosts + 1 << ":";
                            showingLoaneePost(lP);
                        }
                    }
                    noOfPosts++;
                }
            }
            else
            {
                std::cout << "\nSome error occured!!";
            }
        }
        else if (choice == 3)
        {
            std::ifstream Write("patientPosts.txt");
            if (Write.is_open())
            {
                int noOfPosts = 0;
                while (!Write.eof())
                {
                    std::string filePath;
                    std::getline(Write, filePath);
                    std::ifstream Post(filePath);
                    patientPost p;

                    if (Post.is_open())
                    {
                        Post >> p.hospitalName >> p.amount >> p.disease >> p.processName >>
                            p.income >> p.expenses;
                        Post.close();
                        if (p.amount >= startingRange && p.amount <= endRange)
                        {
                            std::cout << "\nPost " << noOfPosts + 1 << ":";
                            showingPatientPost(p);
                        }
                    }
                    noOfPosts++;
                }
            }
            else
            {
                std::cout << "\nSome error occured!!";
            }
        }
    }
    void seeAProfile(int postNo, int postChoice, float *amount, std::string *userProfilePath,
                     std::string *userPostFilePath)
    {
        int lineNo = 1;
        std::string filePath, postFilePath;
        if (postChoice == 1)
        {
            std::ifstream Read("postsStudent.txt");
            if (Read.is_open())
            {
                while (!Read.eof())
                {
                    std::string line;
                    std::getline(Read, line);
                    if (lineNo == postNo)
                    {
                        postFilePath = line;
                        *userPostFilePath = postFilePath;
                        int counter = 0;
                        while (line[counter] != 'p')
                        {
                            counter++;
                        }
                        filePath = line.substr(0, counter);
                        getch();

                        filePath = filePath + ".txt";
                        *userProfilePath = filePath;
                        break;
                    }
                    lineNo++;
                }
            }
            else
            {
                std::cout << "\nInvalid post no!";
                std::cout << "\nPress any key to continue...";
                getch();
                return;
            }
            Read.close();
            userData u;
            verification v;
            Read.open(filePath);
            if (Read.is_open())
            {
                Read >> u.uId >> u.fName >> u.lName >> u.email >>
                    u.password >> u.phoneNo >> u.role >> u.dOB.day >>
                    u.dOB.month >> u.dOB.year >> v.verify >>
                    v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo;
                Read.close();
                std::cout << "\nUser Profile";
                std::cout << "\nName: " << u.fName << " " << u.lName;
                std::cout << "\nPhone No: " << u.phoneNo;
                std::cout << "\nDate Of Birth: " << u.dOB.day << "/" << u.dOB.month << "/" << u.dOB.year;
                std::cout << "\nCnic No: " << v.cnicORcompanyNo;
                std::cout << "\nProfile Posts: ";
                Read.open(postFilePath);
                StudentPost sP;
                Read >> sP.instituteName >> sP.amount >> sP.m.obtMarks >> sP.m.percentage >> sP.m.grade >> sP.hsc.obtMarks >> sP.hsc.percentage >> sP.hsc.grade;
                Read.close();
                *amount = sP.amount;
                showingStudentPost(sP);
            }
        }
        else if (postChoice == 2)
        {
            std::ifstream Read("loaneePosts.txt");
            if (Read.is_open())
            {
                while (!Read.eof())
                {
                    std::string line;
                    std::getline(Read, line);
                    if (lineNo == postNo)
                    {
                        postFilePath = line;
                        *userPostFilePath = postFilePath;
                        int counter = 0;
                        while (line[counter] != 'p')
                        {
                            counter++;
                        }
                        filePath = line.substr(0, counter);
                        getch();

                        filePath = filePath + ".txt";
                        *userProfilePath = filePath;
                        break;
                    }
                    lineNo++;
                }
            }
            else
            {
                std::cout << "\nInvalid post no!";
                return;
            }
            Read.close();
            userData u;
            verification v;
            Read.open(filePath);
            if (Read.is_open())
            {
                Read >> u.uId >> u.fName >> u.lName >> u.email >>
                    u.password >> u.phoneNo >> u.role >> u.dOB.day >>
                    u.dOB.month >> u.dOB.year >> v.verify >>
                    v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo;
                Read.close();
                std::cout << "\nUser Profile";
                std::cout << "\nName: " << u.fName << " " << u.lName;
                std::cout << "\nPhone No: " << u.phoneNo;
                std::cout << "\nDate Of Birth: " << u.dOB.day << "/" << u.dOB.month << "/" << u.dOB.year;
                std::cout << "\nCnic No: " << v.cnicORcompanyNo;
                std::cout << "\nProfile Posts: ";
                Read.open(postFilePath);
                loaneePost lP;
                Read >> lP.amount >> lP.purpose >> lP.employeementType >>
                    lP.jobTitle >> lP.monthlyIncome >> lP.t.annualTax >> lP.t.paidStatus;
                Read.close();
                *amount = lP.amount;
                showingLoaneePost(lP);
            }
        }
        else if (postChoice == 3)
        {
            std::ifstream Read("patientPosts.txt");
            if (Read.is_open())
            {
                while (!Read.eof())
                {
                    std::string line;
                    std::getline(Read, line);
                    if (lineNo == postNo)
                    {
                        postFilePath = line;
                        *userPostFilePath = postFilePath;
                        int counter = 0;
                        while (line[counter] != 'p')
                        {
                            counter++;
                        }
                        filePath = line.substr(0, counter);
                        getch();

                        filePath = filePath + ".txt";
                        *userProfilePath = filePath;
                        break;
                    }
                    lineNo++;
                }
            }
            else
            {
                std::cout << "\nInvalid post no!";
                return;
            }
            Read.close();
            userData u;
            verification v;
            Read.open(filePath);
            if (Read.is_open())
            {
                Read >> u.uId >> u.fName >> u.lName >> u.email >>
                    u.password >> u.phoneNo >> u.role >> u.dOB.day >>
                    u.dOB.month >> u.dOB.year >> v.verify >>
                    v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo;
                Read.close();
                std::cout << "\nUser Profile";
                std::cout << "\nName: " << u.fName << " " << u.lName;
                std::cout << "\nPhone No: " << u.phoneNo;
                std::cout << "\nDate Of Birth: " << u.dOB.day << "/" << u.dOB.month << "/" << u.dOB.year;
                std::cout << "\nCnic No: " << v.cnicORcompanyNo;
                std::cout << "\nProfile Posts: ";
                Read.open(postFilePath);
                patientPost p;
                Read >> p.hospitalName >> p.amount >> p.disease >> p.processName >>
                    p.income >> p.expenses;
                Read.close();
                *amount = p.amount;
                showingPatientPost(p);
            }
        }
    }
    void donateNow(float amount)
    {
        "\nEnter your credit card Details: ";
        cardDetails.cardNo = creditCardValid();
        std::cout << "\nEnter name on card: ";
        fflush(stdin);
        std::cin >> cardDetails.nameOnCard;
        check_string(&cardDetails.nameOnCard);
        std::string stringInput;
        std::cout << "\nEnter card cvv: ";
        fflush(stdin);
        std::cin >> stringInput;
        checkNumber(&stringInput);
        cardDetails.cvv = stoi(stringInput);
        std::string dateInput;
        std::cout << "\nExpire Data: ";
        std::cout << "\nmonth: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        cardDetails.expireDate.expiry_month = stoi(dateInput);
        std::cout << "\nyear: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        cardDetails.expireDate.expiry_year = stoi(dateInput);
        creditCardDateValid(cardDetails.expireDate);
        std::cout << "\nPerfect! " << amount << " Rs has been deducted from your card!";
        std::cout << "\nPress any key to continue......";
        getch();
        return;
    }
    void donateAction()
    {
        std::cout << "\nWant to See home section: \n1: yes \n2: no";
        std::cout << "\nEnter your choice: ";
        int choice;
        while (1)
        {
            fflush(stdin);
            std::cin >> choice;
            if (choice == 1 || choice == 2)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid!\nEnter again: ";
                continue;
            }
        }
        if (choice == 1)
        {
            int postChoice;
            std::cout << "\nWhich needy person posts you want to see: ";
            std::cout << "\n1: Students\n2: Loanee\n3:Patients ";
            std::cout << "\nEnter your choice: ";
            std::string stringInput;
            while (1)
            {
                fflush(stdin);
                std::cin >> stringInput;
                checkNumber(&stringInput);
                postChoice = stoi(stringInput);
                if (postChoice >= 1 && postChoice <= 3)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                    continue;
                }
            }
            std::cout << "\nIn how much amount range you want to see posts: ";
            std::cout << "\nEnter starting range: ";
            int startingRange;
            fflush(stdin);
            std::cin >> stringInput;
            checkNumber(&stringInput);
            startingRange = stoi(stringInput);
            std::cout << "\nEnter end range: ";
            float endRange;
            fflush(stdin);
            std::cin >> stringInput;
            checkNumber(&stringInput);
            endRange = stoi(stringInput);
            homeFunc(postChoice, startingRange, endRange);
            std::cout << "\nWhich post number profile you want to donate: ";
            int postNo;
            fflush(stdin);
            std::cin >> stringInput;
            checkNumber(&stringInput);
            postNo = stoi(stringInput);
            float amount = 0;
            std::string userProfilePath;
            std::string postFilePath;
            seeAProfile(postNo, postChoice, &amount, &userProfilePath, &postFilePath);
            if (amount == 0)
            {
                return;
            }
            char donateChoice;
            std::cout << "\nDonate Now(Y/y for yes, N/n for no) ";
            std::cout << "--> (Other keywords are not accepted!): ";
            while (1)
            {
                fflush(stdin);
                std::cin >> donateChoice;
                if (donateChoice == 'y' || donateChoice == 'Y' || donateChoice == 'N' || donateChoice == 'n')
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid keyword!\nEnter again: ";
                    continue;
                }
            }
            if (donateChoice == 'Y' || donateChoice == 'y')
            {
                donateNow(amount);
                std::ifstream Read(userProfilePath);
                userData u;
                verification v;
                Read >> u.uId >> u.fName >> u.lName >> u.email >> u.password >> u.phoneNo >> u.role >>
                    u.dOB.day >> u.dOB.month >> u.dOB.year >> v.verify >>
                    v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo >> u.amountWithdrawOrDonate;
                float newAmount;
                Read >> newAmount;
                Read.close();
                newAmount += amount;
                std::ofstream Write(userProfilePath);
                Write << u.uId << "\n"
                      << u.fName << "\n"
                      << u.lName << "\n"
                      << u.email << "\n"
                      << u.password << "\n"
                      << u.phoneNo << "\n"
                      << u.role << "\n"
                      << u.dOB.day << "\n"
                      << u.dOB.month << "\n"
                      << u.dOB.year << "\n"
                      << v.verify << "\n"
                      << v.cnicORcompanyNo << "\n"
                      << v.accountType << "\n"
                      << v.bankAccountNo << "\n"
                      << u.amountWithdrawOrDonate << "\n"
                      << newAmount << "\n";
                Write.close();
                Read.open(std::to_string(uD.uId) + ".txt");
                Read >> u.uId >> u.fName >> u.lName >> u.email >> u.password >> u.phoneNo >> u.role >>
                    u.dOB.day >> u.dOB.month >> u.dOB.year >> v.verify >>
                    v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo >> u.amountWithdrawOrDonate;
                Read.close();
                Write.open(std::to_string(uD.uId) + ".txt");
                Write << u.uId << "\n"
                      << u.fName << "\n"
                      << u.lName << "\n"
                      << u.email << "\n"
                      << u.password << "\n"
                      << u.phoneNo << "\n"
                      << u.role << "\n"
                      << u.dOB.day << "\n"
                      << u.dOB.month << "\n"
                      << u.dOB.year << "\n"
                      << v.verify << "\n"
                      << v.cnicORcompanyNo << "\n"
                      << v.accountType << "\n"
                      << v.bankAccountNo << "\n"
                      << u.amountWithdrawOrDonate + amount << "\n";
                Write.close();
                int result = std::remove(postFilePath.c_str());
                if (postChoice == 1)
                {
                    std::ifstream Read("postsStudent.txt");
                    Write.open("temp.txt");
                    while (!Read.eof())
                    {
                        std::string line;
                        std::getline(Read, line);
                        if (line != postFilePath)
                        {
                            Write << line << "\n";
                        }
                    }
                    Write.close();
                    Read.close();
                    std::remove("postsStudent.txt");
                    std::rename("temp.txt", "postsStudent.txt");
                }
                else if (postChoice == 2)
                {
                    std::ifstream Read("postsLoanee.txt");
                    Write.open("temp.txt");
                    while (!Read.eof())
                    {
                        std::string line;
                        std::getline(Read, line);
                        if (line != postFilePath)
                        {
                            Write << line << "\n";
                        }
                    }
                    Write.close();
                    Read.close();
                    std::remove("postsLoanee.txt");
                    std::rename("temp.txt", "postsLoanee.txt");
                }
                else if (postChoice == 3)
                {
                    std::ifstream Read("patientPosts.txt");
                    Write.open("temp.txt");
                    while (!Read.eof())
                    {
                        std::string line;
                        std::getline(Read, line);
                        if (line != postFilePath)
                        {
                            Write << line << "\n";
                        }
                    }
                    Write.close();
                    Read.close();
                    std::remove("patientPosts.txt");
                    std::rename("temp.txt", "patientPosts.txt");
                }
            }
        }
    }
};
class Individual : public Donor
{
public:
    Individual(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nCnic No: " << v.cnicORcompanyNo;
        std::cout << "\nAmount Donate " << uD.amountWithdrawOrDonate;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        uD.amountInAccount = -1;
        editProfAction(uD, v);
        donateAction();
    }
};
class Company : public Donor
{
    struct hackathon
    {
        std::string name, theme, venue;
        dateOfBirth date;
        long long int prize;
        int noOfParticipants;
        std::string judges[3];
        std::string rules[5];
    } hack;

public:
    Company(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void createHackathon()
    {
        std::string inputString;
        std::cout << "\nHackathon name: ";
        fflush(stdin);
        std::cin >> hack.name;
        check_string(&hack.name);
        std::cout << "\nNo Of Participants: ";
        fflush(stdin);
        std::cin >> inputString;
        checkNumber(&inputString);
        hack.noOfParticipants = stoi(inputString);
        std::cout << "\nTheme: ";
        fflush(stdin);
        std::cin >> hack.theme;
        check_string(&hack.theme);
        std::cout << "\nVenue: ";
        fflush(stdin);
        std::cin >> hack.venue;
        check_string(&hack.venue);
        std::cout << "\nDate: ";
        std::string dateInput;
        std::cout << "day: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        hack.date.day = stoi(dateInput);
        while (1)
        {
            if (hack.date.day >=1 && hack.date.day < 32)
            {
                break;
            }
            else
            {
                std::cout <<"\nInvalid day! Enter again: " ;
                std::cin >> dateInput;
                checkNumber(&dateInput);
                hack.date.day = stoi(dateInput);
                continue ; 
            }
        }
        std::cout << "\nmonth: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        hack.date.month = stoi(dateInput);
        while (1)
        {
            if (hack.date.month >= 5  && hack.date.month < 13)
            {
                break;
            }
            else
            {
                std::cout <<"\nInvalid Month! Enter again: " ;
                std::cin >> dateInput;
                checkNumber(&dateInput);
                hack.date.month = stoi(dateInput);
                continue ; 
            }
        }
        std::cout << "\nyear: ";
        fflush(stdin);
        std::cin >> dateInput;
        checkNumber(&dateInput);
        hack.date.year = stoi(dateInput);
        while (1)
        {
            if (hack.date.year == 2023)
            {
                break;
            }
            else
            {
                std::cout <<"\nInvalid Year! Enter again: " ;
                std::cin >> dateInput;
                checkNumber(&dateInput);
                hack.date.year = stoi(dateInput);
                continue ; 
            }
        }
        std::cout << "\nPrize Money: ";
        fflush(stdin);
        std::cin >> hack.prize;
        checkNumber(&inputString);
        hack.prize = stoi(inputString);
        std::cout << "\nEnter judges: ";
        for (int i = 0; i < 3; i++)
        {
            std::cout << "\njudge " << i + 1 << " name: ";
            fflush(stdin);
            std::cin >> hack.judges[i];
            check_string(&hack.judges[i]);
        }
        std::cout << "\nEnter any 5 rules and regulations: ";
        for (int i = 0; i < 5; i++)
        {
            std::cout << "\nRule " << i + 1 << ":";
            fflush(stdin);
            std::cin >> hack.rules[i];
            check_string(&hack.rules[i]);
        }
        std::string filePath = std::to_string(this->uD.uId) + "hack.txt";
        std::ofstream Write(filePath);
        Write << hack.name << "\n"
              << hack.noOfParticipants << "\n"
              << hack.theme << "\n"
              << hack.prize << "\n"
              << hack.venue << "\n"
              << hack.date.day << "\n"
              << hack.date.month << "\n"
              << hack.date.year << "\n";
        for (int i = 0; i < 3; i++)
        {
            Write << hack.judges[i] << "\n";
        }
        for (int i = 0; i < 5; i++)
        {
            Write << hack.rules[i] << "\n";
        }
        Write.close();
        Write.open("hackathonspost.txt", std::ios::app);
        Write << filePath << "\n";
        Write.close();
        std::cout << "\nYour hackathon post has been created!";
        std::cout << "\nPress any key to coninue...";
        getch();
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nLicense No: " << v.cnicORcompanyNo;
        std::cout << "\nAmount Donate: " << uD.amountWithdrawOrDonate;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        uD.amountInAccount = -1;
        editProfAction(uD, v);
        std::string filePath = std::to_string(uD.uId) + "hack.txt";
        std::ifstream Read(filePath, std::ios::binary);
        if (Read.is_open())
        {
            Read >> hack.name >> hack.noOfParticipants >>
                hack.theme >> hack.prize >> hack.venue >> hack.date.day >> hack.date.month >> hack.date.year;
            for (int i = 0; i < 3; i++)
            {
                Read >> hack.judges[i];
            }
            for (int i = 0; i < 5; i++)
            {
                Read >> hack.rules[i];
            }
            Read.close();
            std::cout << "\nYour hackathon post: ";
            std::cout << "\nName: " << hack.name << "\nNo Of Participants: " << hack.noOfParticipants
                      << "\nTheme: " << hack.theme << "\nPrize: " << hack.prize << "\nVenue: " << hack.venue;
            std::cout << "\nDate: " << hack.date.day << "/" << hack.date.month << "/" << hack.date.year;
            std::cout << "\nJudges: ";
            for (int i = 0; i < 3; i++)
            {
                std::cout << "\nJudge " << i + 1 << ":" << hack.judges[i];
            }
            std::cout << "\nRules: ";
            for (int i = 0; i < 5; i++)
            {
                std::cout << "\nRule " << i + 1 << ":" << hack.rules[i];
            }
            std::cout << "\nWhat you want to do about hackathon: \n1:See participants Details: \n2: Delete Hackathon \n3: Nothing\n";
            int hackChoice;
            std::cout << "\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> hackChoice;
                if (hackChoice >= 1 && hackChoice <= 3)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid Choice!\nEnter again: ";
                    continue;
                }
            }
            if (hackChoice == 1)
            {
                std::string filePath = std::to_string(uD.uId) + "participants.txt";
                std::ifstream Read(filePath);
                if (Read.is_open())
                {
                    std::string line;
                    while (std::getline(Read, line))
                    {
                        userData newU;
                        verification newV;
                        std::ifstream participant(line);

                        participant >> newU.uId >> newU.fName >> newU.lName >>
                            newU.email >> newU.password >> newU.phoneNo >> newU.role >>
                            newU.dOB.day >> newU.dOB.month >> newU.dOB.year >> newV.verify >>
                            newV.cnicORcompanyNo >> newV.accountType >>
                            newV.bankAccountNo >> newU.amountWithdrawOrDonate >> newU.amountInAccount;
                        participant.close();
                        std::cout << "\nName: " << newU.fName << " " << newU.lName << "\nEmail: " << newU.email << "\nPhone No: " << newU.phoneNo << "\nDate Of Birth: " << newU.dOB.day << "/" << newU.dOB.month << "/"
                                  << newU.dOB.year << "\n";
                    }
                }
                else
                {
                    std::cout << "\nNo one has applied it!!";
                }
            }
            else if (hackChoice == 2)
            {
                std::remove(filePath.c_str());
                filePath = std::to_string(uD.uId) + "participants.txt";
                std::remove(filePath.c_str());
                std::cout << "\nYour hackathon has been deleted!";
            }
        }
        else
        {
            std::cout << "\nCreate a hackathon: \n1: yes \n2: No";
            int choice;
            std::cout << "\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> choice;
                if (choice == 1 || choice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                    continue;
                }
            }
            if (choice == 1)
            {
                createHackathon();
            }
        }
        donateAction();
    }
};
class Needy : public User
{
public:
    Needy(){};
    Needy(const userData &u)
    {
        this->uD = u;
    }
    virtual void profile()
    {
        User::profile();
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        std::cout << "\nSelect any one of the following donor account types: \n1:Student \n2:Loanee\n3:Unemployeed \n4: Patient";
        std::cout << "\ns/S for student, L/l for loanee, U/u for unemployeed and P/p for patient";
        std::cout << "\nEnter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> v.accountType;
            if (v.accountType == "s" || v.accountType == "S" || v.accountType == "L" || v.accountType == "l" || v.accountType == "U" || v.accountType == "u" ||
                v.accountType == "P" || v.accountType == "p")
            {
                break;
            }
            else
            {
                std::cout << "\nWrong keyword\nEnter again: ";
            }
        }

        std::cout << "\nEnter cnic Number: ";
        fflush(stdin);
        std::cin >> v.cnicORcompanyNo;
        checkNumber(&v.cnicORcompanyNo);
        verifyCnic(&v.cnicORcompanyNo);
        std::cout << "\nEnter bank account number: ";
        fflush(stdin);
        std::cin >> v.bankAccountNo;
        checkNumber(&v.bankAccountNo);
        verifyBankAccount(&v.bankAccountNo);
        v.verify = true;
        writingData(uD, v);
        std::cout << "\nPress any key to continue......";
        getch();
    }
    virtual void createPost(){};
    void amountwithDraw(userData &u, verification &v)
    {
        std::string filePath = std::to_string(u.uId) + ".txt";
        std::ifstream Read(filePath);
        std::cout << "\nHow much amount you want to withdraw (Maximum limit is 100000): ";
        std::string getInput;
        int amount;
        while (1)
        {
            fflush(stdin);
            std::cin >> getInput;
            checkNumber(&getInput);
            amount = stoi(getInput);
            if (amount > 1 && 100000)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid !Try again: ";
            }
        }
        Read >> u.uId >> u.fName >> u.lName >> u.email >> u.password >> u.phoneNo >> u.role >> u.dOB.day >> u.dOB.month >> u.dOB.year >> v.verify >>
            v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo >> u.amountWithdrawOrDonate >> u.amountInAccount;
        Read.close();
        if (amount > u.amountInAccount)
        {
            std::cout << "\nInsufficient Balance!";
            return;
        }
        std::ofstream Write(filePath);
        Write << u.uId << "\n"
              << u.fName << "\n"
              << u.lName << "\n"
              << u.email << "\n"
              << u.password << "\n"
              << u.phoneNo << "\n"
              << u.role << "\n"
              << u.dOB.day << "\n"
              << u.dOB.month << "\n"
              << u.dOB.year << "\n"
              << v.verify << "\n"
              << v.cnicORcompanyNo << "\n"
              << v.accountType << "\n"
              << v.bankAccountNo << "\n"
              << u.amountWithdrawOrDonate + amount << "\n"
              << u.amountInAccount - amount << "\n";
        Write.close();
        std::cout << "Amount has been withdrawed!";
        std::cout << "\nPress any key to continue ";
        getch();
    }
    void withDrawAction(userData &u, verification &v)
    {
        int withDrawChoice;
        std::cout << "\nDo you want to withdraw amount: \n1: yes \n2: no \nEnter your choice: ";
        while (1)
        {
            fflush(stdin);
            std::cin >> withDrawChoice;
            if (withDrawChoice == 1)
            {
                amountwithDraw(u, v);
                break;
            }
            else if (withDrawChoice == 2)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid! Enter again: ";
            }
        }
    }
};
class Student : public Needy
{
    struct post
    {
        std::string instituteName;
        double amount;
        struct matric
        {
            std::string grade;
            float percentage;
            float obtMarks;
        } m, hsc;

    } p;

public:
    Student(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void takeATest()
    {
        std::ifstream Questions("questions.txt");
        std::string answers[5];
        int counter = 0;
        while (!Questions.eof())
        {
            std::string line;
            for (int i = 0; i < 5; i++)
            {
                std::getline(Questions, line);
                if (i == 0)
                {
                    std::cout << "\nQuestion " << counter + 1;
                }
                std::cout << "\n"
                          << line;
            }
            std::cout << "\nEnter your answer: ";
            fflush(stdin);
            std::cin >> answers[counter];
            checkAnswerChoice(&answers[counter]);
            counter++;
        }
        Questions.close();
        std::ifstream Answers("answers.txt");
        int correctAnswers = 0;
        counter = 0;
        while (!Answers.eof())
        {
            std::string readInput;
            std::getline(Answers, readInput);
            if (readInput == answers[counter])
            {
                correctAnswers++;
            }
        }
        Answers.close();
        std::string filePath = std::to_string(uD.uId) + "answers.txt";
        std::ofstream Write(filePath);
        Write << correctAnswers;
        Write.close();
    }
    void createPost()
    {
        std::cout << "\nWhat is your institute: \n1:College \n2:University\nEnter your choice: ";
        int choice;
        while (1)
        {
            fflush(stdin);
            std::cin >> choice;
            if (choice >= 1 && choice <= 2)
            {
                break;
            }
            else
            {
                std::cout << "\nInvalid Type!\nEnter again: ";
            }
        }
        std::cout << "\nEnter institute name: ";
        fflush(stdin);
        std::cin >> p.instituteName;
        check_string(&p.instituteName);
        std::cout << "\nEnter amount needed: ";
        fflush(stdin);
        std::string getInput;
        std::cin >> getInput;
        checkNumber(&getInput);
        p.amount = stoi(getInput);
        if (choice == 1 || choice == 2)
        {
            std::cout << "\nEnter your obtained marks in matric: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> getInput;
                checkNumber(&getInput);
                p.m.obtMarks = stoi(getInput);
                if (p.m.obtMarks > 1100 || p.m.obtMarks < 0)
                {
                    std::cout << "\nInvalid Marks !\nEnter it out of 1100 again : ";
                    continue;
                }
                else
                {
                    break;
                }
            }
            p.m.percentage = (p.m.obtMarks / 1100) * 100;
            p.m.grade = (p.m.percentage >= 80 ? "A+" : p.m.percentage >= 70 ? "A"
                                                   : p.m.percentage >= 60   ? "B"
                                                   : p.m.percentage >= 50   ? "C"
                                                                            : "D");
        }
        if (choice == 2)
        {
            std::cout << "\nEnter your obtained marks in hsc: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> getInput;
                checkNumber(&getInput);
                p.hsc.obtMarks = stoi(getInput);
                if (p.hsc.obtMarks > 1100 || p.hsc.obtMarks < 0)
                {
                    std::cout << "\nInvalid Marks!Enter it again out of 1100: ";
                    continue;
                }
                else
                {
                    break;
                }
            }
            p.hsc.percentage = (p.hsc.obtMarks / 1100) * 100;
            p.hsc.grade = (p.hsc.percentage >= 80 ? "A+" : p.hsc.percentage >= 70 ? "A"
                                                       : p.hsc.percentage >= 60   ? "B"
                                                       : p.hsc.percentage >= 50   ? "C"
                                                                                  : "D");
        }
        std::string filePath = std::to_string(uD.uId) + "post.txt";
        std::ofstream Write(filePath, std::ios::app);
        Write << p.instituteName << "\n"
              << p.amount << "\n"
              << p.m.obtMarks << "\n"
              << p.m.percentage << "\n"
              << p.m.grade << "\n";
        if (choice == 2)
        {
            Write << p.hsc.obtMarks << "\n"
                  << p.hsc.percentage << "\n"
                  << p.hsc.grade << "\n";
        }
        std::cout << "\nYour post has been created!!";
        Write.close();

        Write.open("postsStudent.txt", std::ios::app);
        Write << "\n"
              << filePath;
        Write.close();
        filePath = std::to_string(uD.uId) + "answers.txt";
        Write.open(filePath);
        Write << 0;
        Write.close();
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nCnic No: " << v.cnicORcompanyNo;
        std::cout << "\nAmount Withdraw: " << uD.amountWithdrawOrDonate;
        std::cout << "\nCurrent Amount:" << uD.amountInAccount;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        editProfAction(uD, v);
        withDrawAction(uD, v);
        std::string filePath = std::to_string(uD.uId) + "post.txt";
        std::ifstream Read(filePath, std::ios::binary);
        if (Read.is_open())
        {
            Read >> p.instituteName >> p.amount >> p.m.obtMarks >> p.m.percentage >> p.m.grade;
            p.hsc.grade = "";
            if (!Read.eof())
            {
                Read >> p.hsc.obtMarks >> p.hsc.percentage >> p.hsc.grade;
            }
            Read.close();
            std::cout << "\nYour Post: \nInstitute Name: " << p.instituteName << "\nAmount: " << p.amount << "\nMatric Details: \n"
                      << "Obtained Marks: " << p.m.obtMarks << "\nPercentage: " << p.m.percentage
                      << "%"
                      << "\nGrade: " << p.m.grade;
            if (p.hsc.grade != "")
            {
                std::cout << "\nHSC Details: \nObtained Marks: " << p.hsc.obtMarks
                          << "\nPercentage: " << p.hsc.percentage << "%"
                          << "\nGrade: " << p.hsc.grade;
            }
            int correct;
            filePath = std::to_string(uD.uId) + "answers.txt";
            Read.open(filePath);
            Read >> correct;
            Read.close();
            if (correct > 2)
            {
                std::cout << "\nYour test marks: " << correct;
            }
            else
            {
                std::cout << "\nYour post will not be shown to donor until you don't give correct answers or test: ";
                int choice;
                std::cout << "\nWant to give it:\n1: yes \n2:no \nEnter your choice: ";
                while (1)
                {
                    fflush(stdin);
                    std::cin >> choice;
                    if (choice == 1 || choice == 2)
                    {
                        break;
                    }
                    else
                    {
                        std::cout << "\nInvalid Choice!\nEnter again: ";
                        continue;
                    }
                }
                if (choice == 1)
                {
                    takeATest();
                }
            }
        }
        else
        {
            std::cout << "\nWant to create post: ";
            int createPostChoice;
            std::cout << "\n1: yes \n2: no\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> createPostChoice;
                if (createPostChoice == 1)
                {
                    createPost();
                    break;
                }
                else if (createPostChoice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                }
            }
        }
        std::cout << "\nPress any key to contninue...";
        getch();
    }
};
class Loanee : public Needy
{
    struct post
    {
        double amount;
        std::string purpose, jobTitle, employeementType;
        double monthlyIncome;
        struct taxDetails
        {
            float annualTax;
            bool paidStatus;
        } t;
    } p;

public:
    Loanee(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void createPost()
    {
        p.purpose = "";
        std::cout << "\nFor which purpose you want loan: \n1:Business \n2:Debt Consolidation \n3:Personal Emergencies"
                  << "\n4:Medical Expenses \n5:Home Improvements \n6:Any other purpose";
        std::cout << "\nEnter your choice: ";
        int choice;
        while (1)
        {
            fflush(stdin);
            std::cin >> choice;
            if (choice < 1 || choice > 6)
            {
                std::cout << "\nInvalid Choice!\nEnter again: ";
            }
            else
            {
                break;
            }
        }
        if (choice == 6)
        {
            std::cout << "\nEnter your purpose: ";
            fflush(stdin);
            std::cin >> p.purpose;
            check_string(&p.purpose);
        }
        p.purpose = (choice == 1 ? "Business" : choice == 2 ? "Debt Consolidation"
                                            : choice == 3   ? "Personal Emergencies"
                                            : choice == 4   ? "Medical Expenses"
                                                            : "Home Improvements");
        if (p.purpose != "")
        {
            std::string getInput;
            std::cout << "\nHow much amount you need: ";
            fflush(stdin);
            std::cin >> getInput;
            checkNumber(&getInput);
            p.amount = stoi(getInput);
            std::cout << "\nWhat is your employeement type: \n1: Employeer \n2:Self-Employeed";
            std::cout << "\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> choice;
                if (choice == 1 || choice == 2)
                {
                    p.employeementType = choice == 1 ? "Employeer" : "Self-Employeed";
                    break;
                }
                else
                {
                    std::cout << "\nInvalid Choice!\nEnter again:";
                }
            }
            if (choice == 1)
            {
                std::cout << "\nEnter your job title: ";
            }
            else
            {
                std::cout << "\nEnter which type of sel-employeed you are: ";
            }
            fflush(stdin);
            std::cin >> p.jobTitle;
            check_string(&p.jobTitle);
            std::cout
                << "\nWhat is your monthly income: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> getInput;
                checkNumber(&getInput);
                p.monthlyIncome = stoi(getInput);
                if (p.monthlyIncome < 0)
                {
                    std::cout << "\nInvalid Income!\nEnter again: ";
                }
                else
                {
                    break;
                }
            }
            std::cout << "\nEnter your annual tax:";
            while (1)
            {
                fflush(stdin);
                std::cin >> getInput;
                checkNumber(&getInput);
                p.t.annualTax = stoi(getInput);
                if (p.t.annualTax < 0)
                {
                    std::cout << "\nInvalid Number!\nEnter again: ";
                }
                else
                {
                    break;
                }
            }

            std::cout << "\nDo you have paid your tax( 1 for true, any other keyword for false): ";
            fflush(stdin);
            std::cin >> p.t.paidStatus;
            if (p.t.paidStatus == true)
            {
                std::string filePath = std::to_string(uD.uId) + "post.txt";
                std::ofstream Write(filePath, std::ios::app);
                Write << p.amount << "\n"
                      << p.purpose << "\n"
                      << p.employeementType << "\n"
                      << p.jobTitle << "\n"
                      << p.monthlyIncome << "\n"
                      << p.t.annualTax << "\n"
                      << p.t.paidStatus << "\n";
                Write.close();
                Write.open("loaneePosts.txt", std::ios::app);
                Write << filePath << "\n";
                Write.close();
            }
            else
            {
                std::cout << "\nSorry you can't create post for loan: ";
                return;
            }
        }
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nCnic No: " << v.cnicORcompanyNo;
        std::cout << "\nAmount Withdraw: " << uD.amountWithdrawOrDonate;
        std::cout << "\nCurrent Amount:" << uD.amountInAccount;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        editProfAction(uD, v);
        withDrawAction(uD, v);
        std::string filePath = std::to_string(uD.uId) + "post.txt";
        std::ifstream Read(filePath, std::ios::binary);
        if (Read.is_open())
        {
            Read >> p.amount >> p.purpose >> p.employeementType >> p.jobTitle >> p.monthlyIncome >>
                p.t.annualTax >> p.t.paidStatus;
            Read.close();
            std::cout << "\nYour Post: \nAmount Needed: " << p.amount << "\nPurpose: " << p.purpose << "\nEmployeement Type: " << p.employeementType << "\nJob Title: " << p.jobTitle << "\nMonthly Income: " << p.monthlyIncome << "\nAnnual Tax: " << p.t.annualTax << "\nTax Paid Status: " << p.t.paidStatus;
        }
        else
        {
            std::cout << "\nWant to create post: ";
            int createPostChoice;
            std::cout << "\n1: yes \n2: no\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> createPostChoice;
                if (createPostChoice == 1)
                {
                    createPost();
                    break;
                }
                else if (createPostChoice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                }
            }
        }
        std::cout << "\nPress any key to continue....";
        getch();
    }
};
class Unemployeed : public Needy
{
public:
    Unemployeed(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void hackathonList()
    {
        std::ifstream Write("hackathonspost.txt");
        if (Write.is_open())
        {
            int noOfPosts = 0;
            while (!Write.eof())
            {

                std::string filePath;
                std::getline(Write, filePath);
                std::ifstream Post(filePath);
                hackathon hack;
                if (Post.is_open())
                {
                    Post >> hack.name >> hack.noOfParticipants >>
                        hack.theme >> hack.prize >>
                        hack.venue >> hack.date.day >> hack.date.month >> hack.date.year;
                    for (int i = 0; i < 3; i++)
                    {
                        Post >> hack.judges[i];
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        Post >> hack.rules[i];
                    }
                    Post.close();
                    std::cout << "\nHackathon Post " << noOfPosts + 1;
                    std::cout
                        << "\nName: " << hack.name << "\nNo Of Participants Allowed: " << hack.noOfParticipants
                        << "\nTheme: " << hack.theme << "\nPrize: " << hack.prize << "\nVenue: " << hack.venue;
                    std::cout << "\nDate: " << hack.date.day << "/" << hack.date.month << "/" << hack.date.year;
                    std::cout << "\nJudges: ";
                    for (int i = 0; i < 3; i++)
                    {
                        std::cout << "\nJudge " << i + 1 << ":" << hack.judges[i];
                    }
                    std::cout << "\nRules: ";
                    for (int i = 0; i < 5; i++)
                    {
                        std::cout << "\nRule " << i + 1 << ":" << hack.rules[i];
                    }
                }
                noOfPosts++;
            }
        }
    }
    void hackathonApply(int postNo)
    {
        int lineNo = 1;
        std::string filePath, originalFilePath, hackathonFilePath;
        std::ifstream Read("hackathonspost.txt");
        if (Read.is_open())
        {
            while (!Read.eof())
            {
                std::string line;
                std::getline(Read, line);
                if (lineNo == postNo)
                {
                    int counter = 0;
                    while (line[counter] != 'h')
                    {
                        counter++;
                    }
                    filePath = line.substr(0, counter);
                    originalFilePath = filePath + ".txt";
                    hackathonFilePath = line;
                    filePath = filePath + "participants.txt";
                    break;
                }
                lineNo++;
            }
        }
        else
        {
            std::cout << "\nWrong post no: ";
        }
        Read.close();
        std::string participantFilePath;
        participantFilePath = std::to_string(uD.uId) + ".txt";
        int noOfParticipants = 0;
        Read.open(filePath);
        if (Read.is_open())
        {
            while (!Read.eof())
            {
                noOfParticipants++;
            }
        }
        Read.close();
        Read.open(hackathonFilePath);
        std::string wasteString;
        int fileParticipants;
        Read >> wasteString >> fileParticipants;
        Read.close();
        if (fileParticipants == 1 + noOfParticipants)
        {
            Read.open("hackathonspost.txt");
            std::ofstream Write("temp.txt");
            while (!Read.eof())
            {
                std::string line;
                std::getline(Read, line);
                if (line != hackathonFilePath)
                {
                    Write << line;
                }
            }
            Write.close();
            Read.close();
            std::remove("hackathonspost.txt");
            std::rename("temp.txt", "hackathonspost.txt");
        }
        std::ofstream Write(filePath, std::ios::app);
        Write << participantFilePath << "\n";
        Write.close();
        std::cout << "\nCongratulations! You have applied for hackathon!!";
        std::cout << "\nPress any key to continue....";
        getch();
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nCnic No: " << v.cnicORcompanyNo;
        uD.amountInAccount = -1;
        uD.amountWithdrawOrDonate = -1;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        editProfAction(uD, v);
        std::cout << "\nWant to see hackathons: \n1: yes \n2: no\nEnter your choice: ";
        int choice;
        while (1)
        {
            fflush(stdin);
            std::cin >> choice;
            if (choice == 1 || choice == 2)
            {
                break;
            }
            else
            {
                std::cout << ":\nInvalid! Enter again: ";
                continue;
            }
        }
        if (choice == 1)
        {
            std::cout << "\nHackathons List!";
            hackathonList();
            std::cout << "\nWant to apply: \n1: yes \n2: no";
            std::cout << "\nEnter your choice: ";
            int applyChoice;
            while (1)
            {
                fflush(stdin);
                std::cin >> applyChoice;
                if (applyChoice == 1 || applyChoice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                    continue;
                }
            }
            if (applyChoice == 1)
            {
                int postNo;
                std::cout << "\nEnter the hackaton no: you want to apply: ";
                fflush(stdin);
                std::cin >> postNo;
                hackathonApply(postNo);
            }
        }
        std::cout << "\nHackathons Applied:  ";
        std::ifstream Read("hackathonspost.txt");
        std::string line;
        while (std::getline(Read, line))
        {
            int counter = 0;
            while (line[counter] != 'h')
            {
                counter++;
            }
            std::string filePath = line.substr(0, counter);
            filePath = filePath + "participants.txt";
            std::ifstream hackParticipant(filePath);
            std::string line1;
            while (std::getline(hackParticipant, line1))
            {
                int i = 0;
                while (line1[i] != '.')
                {
                    i++;
                }
                std::string participantUid = line1.substr(0, i);
                if (participantUid == std::to_string(uD.uId))
                {
                    std::ifstream HackathonRead(line);
                    hackathon h;
                    HackathonRead >> h.name >> h.noOfParticipants >> h.theme >> h.prize >> h.venue >>
                        h.date.day >> h.date.month >> h.date.year;
                    for (int i = 0; i < 3; i++)
                    {
                        HackathonRead >> h.judges[i];
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        HackathonRead >> h.rules[i];
                    }
                    std::cout
                        << "\nName: " << h.name << "\nNo Of Participants Allowed: " << h.noOfParticipants
                        << "\nTheme: " << h.theme << "\nPrize: " << h.prize << "\nVenue: " << h.venue;
                    std::cout << "\nDate: " << h.date.day << "/" << h.date.month << "/" << h.date.year;
                    std::cout << "\nJudges: ";
                    for (int i = 0; i < 3; i++)
                    {
                        std::cout << "\nJudge " << i + 1 << ":" << h.judges[i];
                    }
                    std::cout << "\nRules: ";
                    for (int i = 0; i < 5; i++)
                    {
                        std::cout << "\nRule " << i + 1 << ":" << h.rules[i];
                    }
                }
            }
        }
        std::cout << "\nPress any key to continue....";
        getch();
    }
};
class Patient : public Needy
{
    struct post
    {
        double amount;
        std::string hospitalName, disease, processName;
        float income, expenses;
    } p;

public:
    Patient(const userData &u, const verification &v)
    {
        this->uD = u;
        this->v = v;
    }
    void createPost()
    {
        std::string getInput;
        std::cout << "\nHow much amount you need: ";
        fflush(stdin);
        std::cin >> getInput;
        checkNumber(&getInput);
        p.amount = stoi(getInput);
        std::cout << "\nEnter the details of the surgery/operation! ";
        std::cout << "\nEnter hospital name: ";
        fflush(stdin);
        std::cin >> p.hospitalName;
        check_string(&p.hospitalName);
        std::cout << "\nEnter disease name: ";
        fflush(stdin);
        std::cin >> p.disease;
        check_string(&p.disease);
        std::cout << "\nEnter surgery/opeartion name:";
        fflush(stdin);
        std::cin >> p.processName;
        check_string(&p.processName);
        std::cout << "\nEnter your monthly income:";
        fflush(stdin);
        std::cin >> getInput;
        checkNumber(&getInput);
        p.income = stoi(getInput);
        if (p.income > 300000)
        {
            std::cout << "\nSorry you are not eligible for the loan/supportation: ";
            return;
        }
        std::cout << "\nEnter your monthly expenses:";
        fflush(stdin);
        std::cin >> getInput;
        checkNumber(&getInput);
        p.expenses = stoi(getInput);
        if (p.expenses > p.income && p.income > 50000)
        {
            std::cout << "\nSorry you are not eligible for the loan/supportation: ";
            return;
        }
        std::string filePath = std::to_string(uD.uId) + "post.txt";
        std::ofstream Write(filePath, std::ios::app);
        Write << p.hospitalName << "\n"
              << p.amount << "\n"
              << p.disease << "\n"
              << p.processName << "\n"
              << p.income << "\n"
              << p.expenses << "\n";
        Write.close();
        Write.open("patientPosts.txt", std::ios::app);
        Write << filePath << "\n";
        Write.close();
    }
    void profile()
    {
        User::profile();
        std::cout << "\nVerified: "
                  << "Yes";
        std::cout << "\nAccount Type: " << v.accountType;
        std::cout << "\nBank Account : " << v.bankAccountNo;
        std::cout << "\nCnic No: " << v.cnicORcompanyNo;
        std::cout << "\nAmount Withdraw: " << uD.amountWithdrawOrDonate;
        std::cout << "\nCurrent Amount:" << uD.amountInAccount;
        int logOutChoice;
        logOut(uD.uId, &logOutChoice);
        if (logOutChoice == 1)
        {
            return;
        }
        editProfAction(uD, v);
        withDrawAction(uD, v);
        std::string filePath = std::to_string(uD.uId) + "post.txt";
        std::ifstream Read(filePath);
        if (Read.is_open())
        {
            Read >> p.hospitalName >> p.amount >> p.disease >> p.processName >>
                p.income >> p.expenses;
            Read.close();
            std::cout << "\nYour Post: \nAmount Needed: " << p.amount << "\nHospital Name: "
                      << p.hospitalName << "\nDisease: " << p.disease << "\nOperatio/Process Name: "
                      << p.processName << "\nMonthly Income: " << p.income << "\nExpenses: "
                      << p.expenses;
        }
        else
        {
            std::cout << "\nWant to create post: ";
            int createPostChoice;
            std::cout << "\n1: yes \n2: no\nEnter your choice: ";
            while (1)
            {
                fflush(stdin);
                std::cin >> createPostChoice;
                if (createPostChoice == 1)
                {
                    createPost();
                    break;
                }
                else if (createPostChoice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                }
            }
        }
        std::cout << "\nPress any key to continue....";
        getch();
    }
};
class Admin
{
public:
    void identifyingRole(userData &u, verification &v)
    {
        Donor *d;
        Needy *n;
        if ((u.role == "N" || u.role == "n") && v.verify == false)
        {
            n = new Needy(u);
        }
        else if ((u.role == "D" || u.role == "d") && v.verify == false)
        {
            d = new Donor(u);
        }
        else if ((u.role == "N" || u.role == "n") && v.verify == true)
        {
            if (v.accountType == "U" || v.accountType == "u")
            {
                n = new Unemployeed(u, v);
            }
            else if (v.accountType == "S" || v.accountType == "s")
            {
                n = new Student(u, v);
            }
            else if (v.accountType == "L" || v.accountType == "l")
            {
                n = new Loanee(u, v);
            }
            else
            {
                n = new Patient(u, v);
            }
        }
        else
        {
            if (v.accountType == "C" || v.accountType == "c")
            {
                d = new Company(u, v);
            }
            else
            {
                d = new Individual(u, v);
            }
        }
        if (u.role == "d" || u.role == "D")
        {
            d->profile();
            delete d;
        }
        else
        {
            n->profile();
            delete n;
        }
    }
    void logIn()
    {
        std::ifstream Read("currentlyLogin.txt");
        if (Read.is_open())
        {
            system("cls");
            std::string filePath;
            Read >> filePath;
            Read.close();
            Read.open(filePath);
            userData u;
            verification v;
            Read >> u.uId >> u.fName >> u.lName >> u.email >> u.password >> u.phoneNo >> u.role >> u.dOB.day >> u.dOB.month >> u.dOB.year >> v.verify >> v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo >> u.amountWithdrawOrDonate >> u.amountInAccount;
            Read.close();
            identifyingRole(u, v);
        }
        else
        {
            system("cls");
            std::cout << "\n     ********LOGIN  ********";
            std::cout << "\nGo to main Screen: \n1: Yes \n2: No \nEnter your choice: ";
            int backChoice;
            while (1)
            {
                fflush(stdin);
                std::cin >> backChoice;
                if (backChoice == 1)
                {
                    return;
                }
                else if (backChoice == 2)
                {
                    break;
                }
                else
                {
                    std::cout << "\nInvalid! Enter again: ";
                }
            }
            std::string filePath;
            std::string email, password;
            std::cout << "\nEnter your email: ";
            fflush(stdin);
            std::cin >> email;
            std::ifstream infile("users.txt");
            std::string line;
            bool userFound = false;
            while (getline(infile, line))
            {
                if (line.substr(0, email.length()) == email)
                {
                    userFound = true;
                    filePath = line.substr(email.length() + 1);
                    break;
                }
            }
            infile.close();
            if (!userFound)
            {
                std::cout << "This account does not exist. Please try again with a valid a account email" << std::endl;
                return;
            }
            std::cout << "\nEnter your password: ";
            fflush(stdin);
            std::cin >> password;
            FILE *filePtr = fopen(filePath.c_str(), "rb");
            std::ifstream Read(filePath, std::ios::binary);
            if (!Read.is_open())
            {
                std::cout << "\nSome Error Occured!";
            }
            else
            {

                userData u;
                verification v;
                Read >> u.uId >> u.fName >> u.lName >> u.email >> u.password >> u.phoneNo >> u.role >> u.dOB.day >> u.dOB.month >> u.dOB.year >> v.verify;
                if (!Read.eof())
                {
                    Read >> v.cnicORcompanyNo >> v.accountType >> v.bankAccountNo >> u.amountWithdrawOrDonate;
                    if (!Read.eof())
                    {
                        Read >> u.amountInAccount;
                    }
                }
                Read.close();
                if (u.password == password)
                {
                    std::cout << "\nSuccessfully login!";
                    std::ofstream Write("currentlyLogin.txt");
                    std::string filePath = std::to_string(u.uId) + ".txt";
                    Write << filePath;
                    Write.close();
                    std::cout << "\nPress any key to continue....";
                    getch();
                    identifyingRole(u, v);
                }
                else
                {
                    std::cout << "\nWrong Password!";
                }
            }
        }
        logIn();
    }
};

int main()
{
    std::cout << "\nWhat do you want to do: ";
    std::cout << "\n1: Login \n2: SignUp \n3: Exit";
    int choice;
    std::cout << "\nEnter your choice: ";
    while (1)
    {
        fflush(stdin);
        std::cin >> choice;
        if (choice == 1 || choice == 2 || choice == 3)
        {
            break;
        }
        else
        {
            std::cout << "\nInvalid! Enter again: ";
            continue;
        }
    }
    if (choice == 1)
    {
        Admin a;
        a.logIn();
    }
    else if (choice == 2)
    {
        User u;
        u.signUp();
    }
    else
    {
        exit(1);
    }
    main();
}